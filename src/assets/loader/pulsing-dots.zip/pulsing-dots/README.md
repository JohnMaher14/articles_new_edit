# Pulsing Dots

A Pen created on CodePen.io. Original URL: [https://codepen.io/ekfuhrmann/pen/KKZJvGN](https://codepen.io/ekfuhrmann/pen/KKZJvGN).

Inspired by Oleg Frolov's Activity Indicator, I created a GSAP version of dots animating in a loop.

https://dribbble.com/shots/7513996-Activity-Indicator